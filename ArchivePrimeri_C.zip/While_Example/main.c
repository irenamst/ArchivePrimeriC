#include <stdio.h>
#include <stdlib.h>

int main()
{
    int iCond=0;
    while(iCond!=3){
        printf("If you want a message press 1\n");
        printf("If you want the answer of the universe press 2\n");
        printf("If you want to exit press 3\n");
        scanf("%d",&iCond);
        switch(iCond){
    case 1:
        printf("Hello!\n");
        break;
    case 2:
        printf("The answer of the universe is 42.\n");
        break;
    case 3:
        printf("break %d\n",iCond);
        break;
    default:
        break;
        };
    }

    return 0;
}
