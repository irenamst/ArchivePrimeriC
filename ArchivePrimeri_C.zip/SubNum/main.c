#include <stdio.h>
#include <stdlib.h>

int sub(int numOne, int numTwo);

int main()
{
    int res = sub(3,6);
    printf("res = %d\n",res);
    return 0;
}
int sub(int a, int b){
    return a - b;
}
