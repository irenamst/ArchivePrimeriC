#include <stdio.h>
#include <stdlib.h>

int add(int a, int b);
int main()
{

    int res = add(3,6);
    printf("res = %d\n",res);
    return 0;
}
int add(int a, int b){
    return a+b;
}
