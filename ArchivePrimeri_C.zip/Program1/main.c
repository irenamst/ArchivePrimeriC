#include <stdio.h>
#include <stdlib.h>

unsigned int f(unsigned int x)
    {
        x &=~(1<<3);
        return x;
    }
int main()
{
    unsigned int x = f(31);
    printf("%d",x);
    return 0;
}
