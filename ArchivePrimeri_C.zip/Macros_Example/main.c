#include <stdio.h>
#include <stdlib.h>
#define X 65545

int main()
{
    printf("X = %d\n",X);
    return 0;
}
