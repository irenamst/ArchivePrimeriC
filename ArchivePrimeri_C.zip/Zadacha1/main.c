#include <stdio.h>
#include <stdlib.h>

int main()
{
    int weigth;
    scanf("%d",&weigth);
    weigth = 0.17*weigth;
    printf("%d\n",weigth);
    return 0;
}
