#include <stdio.h>
#include <stdlib.h>


int main()
{
  int16 *p = (void *)0x10001234;
  p+=4;
    printf("%x",p);
    return 0;
}
