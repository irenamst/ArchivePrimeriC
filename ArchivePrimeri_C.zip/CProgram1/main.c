#include <stdio.h>
#include <stdlib.h>
typedef struct node *link;
struct node{(1,9),};
int main()
{
    printf("Hello world!\n");
    return 0;
}
