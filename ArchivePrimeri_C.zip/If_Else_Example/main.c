#include <stdio.h>
#include <stdlib.h>

int main()
{
    int iComp=0;
    if(iComp){
        printf("i=%d\n",iComp);
    }
    else{
    printf("i=0\n");
    }

    return 0;
}
