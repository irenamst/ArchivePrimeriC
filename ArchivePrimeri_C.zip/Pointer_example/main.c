#include <stdio.h>
#include <stdlib.h>

int main()
{
    int iVal=42, iNew=33;
    int *p_iVal=0;
    p_iVal=&iVal;
    printf("p_iVal=%d\n",*p_iVal);
    *p_iVal=12;
    printf("p_iVal=%d\n",*p_iVal);
    p_iVal=&iNew;
    printf("p_iVal=%d\n",*p_iVal);
    return 0;
}
